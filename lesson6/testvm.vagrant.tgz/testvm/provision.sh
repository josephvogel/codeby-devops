#!/bin/bash
set -e

ROLE="${1:-}"
KEY_DIR="/vagrant/keys"
KEY_FILE="$KEY_DIR/id_ed25519"

if [ "$ROLE" = "client" ]; then

    mkdir -p "$KEY_DIR"
    if [ ! -f "$KEY_FILE" ]; then
        ssh-keygen -t ed25519 -N '' -f "$KEY_FILE" -C 'client-to-server'
    fi
    chmod 600 "$KEY_FILE" && chmod 644 "$KEY_FILE.pub"

    # Приватный ключ для пользователя vagrant на client
    install -d -m 700 -o vagrant -g vagrant /home/vagrant/.ssh
    install -m 600 -o vagrant -g vagrant "$KEY_FILE" /home/vagrant/.ssh/id_ed25519

    # Резолвинг имени server и ssh-алиас
    grep -qE '^[[:space:]]*192\.168\.1\.103[[:space:]]+server' /etc/hosts || echo "192.168.56.20 server" >> /etc/hosts

    cat > /home/vagrant/.ssh/config <<'EOF'
Host server
    HostName 192.168.1.103
    User server
    IdentityFile ~/.ssh/id_ed25519
    IdentitiesOnly yes
    StrictHostKeyChecking accept-new
EOF
    chown vagrant:vagrant /home/vagrant/.ssh/config
    chmod 600 /home/vagrant/.ssh/config
fi

if [ "$ROLE" = "server" ]; then
   
    id -u server >/dev/null 2>&1 || useradd -m -s /bin/bash server

    for i in $(seq 1 60); do
        [ -f "$KEY_FILE.pub" ] && break
        echo "Waiting for public key from client... ($i)"
        sleep 2
    done

    if [ ! -f "$KEY_FILE.pub" ]; then
        echo "ERROR: public key not found in /vagrant/keys" >&2
        exit 1
    fi

    install -d -m 700 -o server -g server /home/server/.ssh
    install -m 600 -o server -g server "$KEY_FILE.pub" /home/server/.ssh/authorized_keys
fi
